# TMM21-LF-MKC-LKA
You can run genarateNeighborhood.m to generate local kernels and use lateFusuinglocalAlignmentDemo.m to get final results.
