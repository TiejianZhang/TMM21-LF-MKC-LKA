# latefusionalignment
Matlab implementation for newly proposed multi-view clustering with localized late fusion alignment maximization （LMVC-LFA）


主执行文件为lateFusingAlignmentdemo.m,示例数据集为ccv（多核数据集。超过文件限制无法上传，可自行产生多核矩阵）.

如果有任何问题或者数据集问题，请联系wangsiwei13@nudt.edu.cn.
