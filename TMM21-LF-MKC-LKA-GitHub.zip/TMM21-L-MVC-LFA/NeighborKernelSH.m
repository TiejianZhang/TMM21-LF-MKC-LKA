function Kernel = NeighborKernelSH(AVGKer, Rate)

NeiNum = round( Rate * size(AVGKer , 1) );

AA = genarateNeighborhood(AVGKer , NeiNum);

Kernel = KernelGeneration(AVGKer, AA);

end