clear
clc
warning off;

path = './Datasets/Kernel/';
addpath(genpath(path));

DataName = cell(19, 1);

DataName{1} = 'AR10P';
DataName{2} = 'YALE';
DataName{3} = 'plant';
DataName{4} = 'mfeat';
DataName{5} = 'flower17';
DataName{6} = 'CCV';
DataName{7} = 'caltech101_nTrain5_48';
DataName{8} = 'caltech101_nTrain10_48';
DataName{9} = 'caltech101_nTrain15_48';
DataName{10} = 'caltech101_nTrain20_48';
DataName{11} = 'caltech101_nTrain25_48';
DataName{12} = 'caltech101_nTrain30_48';
addpath('.\ClusteringEvaluation\');
for ii = 1:2
    dataName = DataName{ii};
    disp(dataName);
    load([path,dataName,'_Kmatrix'],'KH','Y');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    numclass = length(unique(Y));
    numker = size(KH,3);
    num = size(KH,1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    KH = kcenter(KH);
    KH = knorm(KH);
    
    HP = zeros(num,numclass,numker);
    
    qnorm = 2;
    
    opt.disp = 0;
    
    for p=1:numker % m - kernels
        KH(:,:,p) = (KH(:,:,p)+KH(:,:,p)')/2;
    end
    
    gamma0 = ones(numker,1)/numker;
    avgKer  = mycombFun(KH,gamma0); 
    

    lambdaset9 = 2.^[-10:1:-10];
    tauset9 = [0.05:0.05:0.95];
    
    accval9 = zeros(length(lambdaset9),length(tauset9));
    nmival9 = zeros(length(lambdaset9),length(tauset9));
    purval9 = zeros(length(lambdaset9),length(tauset9));
    time = zeros(length(lambdaset9),length(tauset9));
    KHL = zeros(size(KH));
    
dataPath = ['.\Datasets\LocalKernel\'];
    for it =1:length(tauset9)
        load([dataPath ,dataName ,'_neibournum_ ',...
        num2str(tauset9(it)),'.mat'], 'localH','localavg');

        for ij = 1:length(lambdaset9)
            tic;
            [H_normalized9,WP9,gamma9,obj9] = multikernellocalLatefusionAlignmentclustering(localH,numclass,...
                lambdaset9(ij),Y,localavg);
            res9 = myNMIACCV2(H_normalized9,Y,numclass);
            accval9(ij,it) = res9(1);
            nmival9(ij,it)= res9(2);
            purval9(ij,it) = res9(3);
            ARIval9(ij,it) = res9(4);
            time(it,ij) = toc;
        end
    end
    res = [max(max(accval9)); max(max(nmival9));max(max(purval9));max(max(ARIval9))];
    
    save(['.\Result\Time\' , dataName , '.mat'],'time')
    save(['.\Result\BestACCNMI\' , dataName , '.mat'], 'res','accval9','nmival9','purval9','ARIval9')
end


