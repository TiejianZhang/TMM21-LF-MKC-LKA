clear
clc
warning off;

path = './Datasets/Kernel/';
addpath(genpath(path));

DataName = cell(19, 1);
DataName{1} = 'AR10P';
DataName{2} = 'YALE';
DataName{3} = 'plant';
DataName{4} = 'mfeat';
DataName{5} = 'flower17';
DataName{6} = 'CCV';
DataName{7} = 'caltech101_nTrain5_48';
DataName{8} = 'caltech101_nTrain10_48';
DataName{9} = 'caltech101_nTrain15_48';
DataName{10} = 'caltech101_nTrain20_48';
DataName{11} = 'caltech101_nTrain25_48';
DataName{12} = 'caltech101_nTrain30_48';

addpath('.\ClusteringEvaluation');
savePath = '.\Datasets\LocalKernel\';

for ii = 2
    dataName = DataName{ii};
    disp(dataName);
    load([path,dataName,'_Kmatrix'],'KH','Y');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    numclass = length(unique(Y));
    numker = size(KH,3);
    num = size(KH,1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    KH = kcenter(KH);
    KH = knorm(KH);
    
    HP = zeros(num,numclass,numker);
    
    qnorm = 2;
    
    opt.disp = 0;
    
    for p=1:numker % m - kernels
        KH(:,:,p) = (KH(:,:,p)+KH(:,:,p)')/2;
    end
    
    gamma0 = ones(numker,1)/numker;
    avgKer  = mycombFun(KH,gamma0); 
    
        %%---The Proposed2 time---%%
%     tic
    lambdaset9 = 2.^[-10:2:10];
    tauset9 = [0.05:0.05:0.95];

    KHL = zeros(size(KH));
    avgKerL = zeros(size(avgKer));
    localH = zeros(num,numclass,numker);
    localavg = zeros(num,numclass);
    for it =1:length(tauset9)
        [KHL, avgKerL] = LocalKernelCalculation(KH, avgKer, tauset9(it));

        for i = 1:numker
            localH(:,:,i) = mykernelkmeans(KHL(:,:,i),numclass);
        end
        localavg = mykernelkmeans(avgKerL,numclass);
        
        if exist(savePath)==0  
        mkdir(savePath);
        end
        
        save([savePath, dataName ,'_neibournum_ ',...
        num2str(tauset9(it)),'.mat'], 'localH','localavg');
    end   

end