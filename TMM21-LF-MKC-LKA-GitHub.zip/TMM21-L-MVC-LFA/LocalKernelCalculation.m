function [KHL, avgKerL] = LocalKernelCalculation(KH, avgKer, NNRate)

[SampleNum , ~ , KerNum] = size(KH);

gamma0 = ones(KerNum,1)/KerNum;
% avgKer  = mycombFun(KH,gamma0);

KHL = zeros(size(KH));
avgKerL = zeros(size(KH));
SumN = zeros(size(KH,1));

SumN = NeighborKernelSH(avgKer, NNRate);

avgKerL = SumN .* avgKer;
avgKerL = (avgKerL + avgKerL') / 2;
avgKerL = NormalizingKernelMatrix_V2(avgKerL);
avgKerL = (avgKerL + avgKerL')/2 + eye(SampleNum)*10^(-8);

for kk = 1 : KerNum
%     KHL(:,:,kk) = NeighborKernelSH(KH(:,:,kk) , avgKer, NNRate);
    KHL(:,:,kk) = SumN .* KH(:,:,kk);
    KHL(:,:,kk) = ( KHL(:,:,kk) + KHL(:,:,kk)' ) / 2;
end

for BKNum = 1 : KerNum
    KHL(:,:,BKNum) = NormalizingKernelMatrix_V2(KHL(:,:,BKNum));
    KHL(:,:,BKNum) = (KHL(:,:,BKNum) + KHL(:,:,BKNum)')/2 + eye(SampleNum)*10^(-8);
end
end